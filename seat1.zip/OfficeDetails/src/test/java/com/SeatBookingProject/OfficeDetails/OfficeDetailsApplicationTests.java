package com.SeatBookingProject.OfficeDetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OfficeDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
